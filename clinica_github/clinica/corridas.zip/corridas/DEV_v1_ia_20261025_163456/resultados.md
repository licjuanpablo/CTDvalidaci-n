# Resultados DEV_v1_ia_20261025_163456

Casos: 21 (deben objetarse: 8; aptos: 13)

| Métrica | Valor |
|---|---|
| Sensibilidad (objeta los que deben objetarse) | 8/8 = 100% (IC95 63%–100%) |
| Especificidad (no objeta los aptos) | 13/13 = 100% (IC95 75%–100%) |
| Exactitud del dictamen | 21/21 = 100% (IC95 84%–100%) |
| Exactitud de la asignación Calidad/Clínica/Ambas | 21/21 = 100% (IC95 84%–100%) |
| Motivo de objeción correcto (incluye todos los esperados, sin objeciones en aptos) | 21/21 = 100% (IC95 84%–100%) |
| Observaciones/información esperadas presentes | 5/5 = 100% (IC95 48%–100%) |
| Sugerencia de asignación de Gemini (no vinculante) | 18/21 = 86% (IC95 64%–97%) |

IC 95 % exacto de Clopper-Pearson.

## Matriz de asignación (filas = esperado, columnas = sistema)

| | Calidad | Clínica | Ambas | otro |
|---|---|---|---|---|
| Calidad | 2 | 0 | 0 | 0 |
| Clínica | 0 | 17 | 0 | 0 |
| Ambas | 0 | 0 | 2 | 0 |

## Errores
