# Resultados TEST_final_v1_20261025_1342

Casos: 39 (deben objetarse: 19; aptos: 20)

| Métrica | Valor |
|---|---|
| Sensibilidad (objeta los que deben objetarse) | 19/19 = 100% (IC95 82%–100%) |
| Especificidad (no objeta los aptos) | 20/20 = 100% (IC95 83%–100%) |
| Exactitud del dictamen | 39/39 = 100% (IC95 91%–100%) |
| Exactitud de la asignación Calidad/Clínica/Ambas | 39/39 = 100% (IC95 91%–100%) |
| Motivo de objeción correcto (incluye todos los esperados, sin objeciones en aptos) | 39/39 = 100% (IC95 91%–100%) |
| Observaciones/información esperadas presentes | 8/8 = 100% (IC95 63%–100%) |
| Sugerencia de asignación de Gemini (no vinculante) | 28/39 = 72% (IC95 55%–85%) |

IC 95 % exacto de Clopper-Pearson.

## Matriz de asignación (filas = esperado, columnas = sistema)

| | Calidad | Clínica | Ambas | otro |
|---|---|---|---|---|
| Calidad | 3 | 0 | 0 | 0 |
| Clínica | 0 | 33 | 0 | 0 |
| Ambas | 0 | 0 | 3 | 0 |

## Errores
